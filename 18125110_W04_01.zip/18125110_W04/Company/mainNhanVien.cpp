#include"NhanVien.h"
int main() {
	NVCongNhat a;
	a.input();
	a.displayLuong();


	system("pause");
	return 0;
}